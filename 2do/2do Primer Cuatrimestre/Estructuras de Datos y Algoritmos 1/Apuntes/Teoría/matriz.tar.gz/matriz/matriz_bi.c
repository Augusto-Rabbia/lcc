#include "matriz.h"

/*
** Implementacion utilizando un arreglo bidimensional (arreglo de punteros a arreglo)
*/

struct Matriz_ {

  /*Defina la estructura aqui*/

};


Matriz* matriz_crear(size_t numFilas, size_t numColumnas) {

}

void matriz_destruir(Matriz* matriz) {

}

double matriz_leer(Matriz* matriz, size_t fil, size_t col) {

}

void matriz_escribir(Matriz* matriz, size_t fil, size_t col, double val) {

}

size_t matriz_num_filas(Matriz* matriz) {

}

size_t matriz_num_columnas(Matriz* matriz) {

}


